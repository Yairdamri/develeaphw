#!/bin/bash

# Default: verbose disabled
verbose=0

# Parse options
while getopts "v" opt; do
    case $opt in 
        v)
            echo "Verbose mode enabled"
            verbose=1
            ;;
        *)
            echo "Usage: $0 [-v]"
            exit 1
            ;;
    esac
done

# Always run basic info
echo "System Information Report"
uname -a
echo "---------------------------------------------"

# If verbose enabled → print extra details
if [ "$verbose" -eq 1 ]; then
    echo "Verbose mode: collecting additional system information..."
    echo "Disk Usage"
    du -h --max-depth=1
    echo "---------------------------------------------"
    echo "Memory Usage"
    free -h
    echo "---------------------------------------------"
    echo "Number of Packages Installed"
    dpkg -l | grep '^ii' | wc -l                     
    echo "---------------------------------------------"
    echo "CPU Information"
    lscpu
    echo "---------------------------------------------"
    echo "Disk Report saved to disk-report-$(date +%Y-%m-%d-%H-%M-%S).log"
fi

# Save report to a file