\#!/bin/bash/
echo "Performing system backup..."
echo "Backup completed on $(date)"
